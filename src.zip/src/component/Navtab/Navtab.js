import React from "react";

const Navtab = () => {
  return <section>
    <ul>
        <li>All</li>
    </ul>
  </section>;
};

export default Navtab;
