import React from 'react'


const Home = () => {
  return (
    <>
        <h1>bhbhgvhghgv</h1>
    </>
  )
}

export default Home
